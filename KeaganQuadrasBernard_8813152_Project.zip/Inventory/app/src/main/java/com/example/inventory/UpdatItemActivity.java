package com.example.inventory;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class UpdatItemActivity extends AppCompatActivity {
    EditText product_name_edit, product_price_edit, product_quantity_edit ,product_description_edit;
    String id, name, price, quantity, desc;
    CardView cv_text_save,cv_delete_save;
    TextView save;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        // initialize views
        cv_delete_save = findViewById(R.id.cv_delete_save);
        cv_delete_save.setVisibility(View.VISIBLE);
        product_name_edit = findViewById(R.id.product_name_edit);
        product_price_edit = findViewById(R.id.product_price_edit);
        product_quantity_edit = findViewById(R.id.product_quantity_edit);
        product_description_edit = findViewById(R.id.product_description_edit);
        cv_text_save = findViewById(R.id.cv_text_save);
        save =findViewById(R.id.save);
        save.setText(R.string.update);


        getSetIntentData();

        // change  toolbar text to Product name.
        ActionBar ab = getSupportActionBar();
        if (ab != null) {
            ab.setTitle(name);

        }

        // update text by pressing update button.
        cv_text_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(product_name_edit.getText().toString().trim().isEmpty()) {
                    Toast.makeText(UpdatItemActivity.this, "Please Enter Product Name", Toast.LENGTH_SHORT).show();

                }
                else if( product_price_edit.getText().toString().trim().isEmpty()) {
                    Toast.makeText(UpdatItemActivity.this, "Please Enter Total Product Price", Toast.LENGTH_SHORT).show();

                }
                else if(product_quantity_edit.getText().toString().trim().isEmpty()) {
                    Toast.makeText(UpdatItemActivity.this, "Please Enter Quanity", Toast.LENGTH_SHORT).show();

                }
                else if(product_description_edit.getText().toString().trim().isEmpty()) {
                    Toast.makeText(UpdatItemActivity.this, "Please Enter Description", Toast.LENGTH_SHORT).show();

                }else {


                    //update data.
                    DatabaseClass db = new DatabaseClass(UpdatItemActivity.this);
                    name = product_name_edit.getText().toString().trim();
                    price = product_price_edit.getText().toString().trim();
                    quantity = product_quantity_edit.getText().toString().trim();
                    desc = product_description_edit.getText().toString().trim();
                    db.updateData(id, name, price, quantity, desc);
                }
            }
        });

        //delete one data .
        cv_delete_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                alertDialog();
            }
        });

    }

    // set data by getting data from  other activity
    void getSetIntentData(){
        if(getIntent().hasExtra("id") && getIntent().hasExtra("name") &&
                getIntent().hasExtra("price") && getIntent().hasExtra("quan") && getIntent().hasExtra("desc") ){
            //Getting Data from Intent
            id = getIntent().getStringExtra("id");
            name = getIntent().getStringExtra("name");
            price = getIntent().getStringExtra("price");
            quantity = getIntent().getStringExtra("quan");
            desc =  getIntent().getStringExtra("desc");
           // set data in views .
            product_name_edit.setText(name);
            product_price_edit.setText(price);
            product_quantity_edit.setText(quantity);
            product_description_edit.setText(desc);
            Log.d("check", name+" "+price+" "+quantity);
        }
        else{
            Toast.makeText(this, "No data Found.", Toast.LENGTH_SHORT).show();
        }
    }


    // confirm to delete single items
    void alertDialog(){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Delete " + name + " ?");
        builder.setMessage("Are you sure you want to delete " + name + " ?");
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
               // call database to change data.
                DatabaseClass db = new DatabaseClass(UpdatItemActivity.this);
                db.deleteSingleItem(id);
                finish();
            }
        });
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

            }
        });
        builder.create().show();
    }
}