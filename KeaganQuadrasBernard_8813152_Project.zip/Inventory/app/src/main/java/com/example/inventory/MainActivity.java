package com.example.inventory;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    RecyclerView recyclerView;
    TextView add_items,no_data;
    EditText search;
    CardView cv_add_items;
    DatabaseClass database;

    List<RecyclerAdapterBean> recyclerbean;
    RecyclerViewAdapter recyclerAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //initialize paramters.
        search =findViewById(R.id.search);
        recyclerView = findViewById(R.id.recyclerview);
        add_items = findViewById(R.id.additems);
        cv_add_items =findViewById(R.id.cv_add_items);
        no_data =findViewById(R.id.no_data);

        //  items can be search by calling this method.
        search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                searchList(String.valueOf(s));
            }
        });

        //add items by click add items buttons  : send to anther Screen.
        cv_add_items.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, AddItemActivity.class);
                startActivity(intent);
            }
        });


        // initialize database
        database = new DatabaseClass(MainActivity.this);

        // initalize arraylist
        recyclerbean = new ArrayList<RecyclerAdapterBean>();

        // read all data by this method .
        saveDataToDisplay();

        // calling recycler view items and send list to recyclerview adapter .
        recyclerAdapter = new RecyclerViewAdapter(MainActivity.this,this, recyclerbean);
        recyclerView.setAdapter(recyclerAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(MainActivity.this));
    }


    // sget data from database to display on screen.
    void saveDataToDisplay(){
        Cursor cursor = database.readProdData();
        // if there is no data diaplay then show a message  : add items to display data.
        if(cursor.getCount() == 0){

            no_data.setVisibility(View.VISIBLE);
        }else{
            while (cursor.moveToNext()){

               // get data one by one .
                String id = cursor.getString(0);
                String name = cursor.getString(1);
                String price = cursor.getString(2);
                String quant = cursor.getString(3);
                String desc = cursor.getString(4);


                // add data in bean class
                RecyclerAdapterBean bean = new RecyclerAdapterBean();
                bean.setId(id);
                bean.setName(name);
                bean.setPrice(price);
                bean.setQuant(quant);
                bean.setDesc(desc);
                 // add data in array list.
                recyclerbean.add(bean);
            }

            no_data.setVisibility(View.GONE);
        }
    }

    // search items by product name
    public void searchList(String text){
       // new arraylist
        ArrayList<RecyclerAdapterBean> searchItems = new ArrayList<>();
       // set all data to lower case
         for(RecyclerAdapterBean item : recyclerbean){
            if(item.getName().toLowerCase().contains(text.toLowerCase())){
                searchItems.add(item);
            }

        }
         // if data is not matched with user text.
        if(searchItems.isEmpty()){
            Toast.makeText(this, "No Data Found", Toast.LENGTH_SHORT).show();
        }
        // display data if user search the data from the list display.
        else{
            recyclerAdapter.searchProdList(searchItems);
        }
    }

    // delete all items bu this menu.
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.my_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == 1){
            recreate();
        }
    }


    // delete all data
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId() == R.id.delete_all){
            //call alert dialog
            AlertDialog();
        }
        return super.onOptionsItemSelected(item);
    }

    //confirm if user wants to delete all data.
    void AlertDialog(){


        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Delete All ");
        builder.setMessage("Are you sure you want to delete all Data?");
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                // delete all data from database.
                DatabaseClass db = new DatabaseClass(MainActivity.this);
                db.deleteAllItems();
                Intent intent = new Intent(MainActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
            }
        });
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

            }
        });
        builder.create().show();
    }
}