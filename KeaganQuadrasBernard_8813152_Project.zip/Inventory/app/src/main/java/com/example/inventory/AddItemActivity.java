package com.example.inventory;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class AddItemActivity extends AppCompatActivity {

    EditText product_name_edit, product_price_edit, product_quantity_edit, product_description_edit;
    TextView save;
    CardView cv_text_save,cv_delete_save;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);
        // initialize views
        cv_delete_save = findViewById(R.id.cv_delete_save);
        product_name_edit = findViewById(R.id.product_name_edit);
        product_price_edit = findViewById(R.id.product_price_edit);
        product_quantity_edit = findViewById(R.id.product_quantity_edit);
        product_description_edit = findViewById(R.id.product_description_edit);
        cv_text_save = findViewById(R.id.cv_text_save);
        save = findViewById(R.id.save);

        //initialize Database
        DatabaseClass db = new DatabaseClass(AddItemActivity.this);


        save.setText(R.string.save);
        cv_delete_save.setVisibility(View.GONE);

        //save data in database and validations
        cv_text_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
              // validations
                if(product_name_edit.getText().toString().trim().isEmpty()) {
                    Toast.makeText(AddItemActivity.this, "Please Enter Product Name", Toast.LENGTH_SHORT).show();

                }
               else if( product_price_edit.getText().toString().trim().isEmpty()) {
                    Toast.makeText(AddItemActivity.this, "Please Enter Total Product Price", Toast.LENGTH_SHORT).show();

                }
               else if(product_quantity_edit.getText().toString().trim().isEmpty()) {
                    Toast.makeText(AddItemActivity.this, "Please Enter Quanity", Toast.LENGTH_SHORT).show();

                }
               else if(product_description_edit.getText().toString().trim().isEmpty()) {
                    Toast.makeText(AddItemActivity.this, "Please Enter Description", Toast.LENGTH_SHORT).show();

                }else {
                       // save data in database
                    db.addProd(product_name_edit.getText().toString().trim(),
                            product_price_edit.getText().toString().trim(),
                            product_quantity_edit.getText().toString().trim(),
                            product_description_edit.getText().toString().trim()
                    );
                }

            }
        });
    }
}