package com.example.inventory;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import android.widget.TextView;

import androidx.annotation.NonNull;

import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.MyViewHolder> {
    private Context context;
    private Activity activity;
    List<RecyclerAdapterBean> recyclerbean;


    //constructor
    public RecyclerViewAdapter(Activity mainActivity, Context context,
                               List<RecyclerAdapterBean> recyclerbean) {
        // get data from previous activity.
        this.activity = mainActivity;
        this.context = context;
        this.recyclerbean= recyclerbean;

    }



    // search product list.
    public void searchProdList(ArrayList<RecyclerAdapterBean> list){
        this.recyclerbean = list;
        notifyDataSetChanged();
    }


    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        // inflate views
        View view = inflater.inflate(R.layout.recylcler_items, parent, false);
        return new MyViewHolder(view);
    }


    @Override
    public void onBindViewHolder(@NonNull  MyViewHolder holder, int position) {


     final RecyclerAdapterBean recyclerAdapterBean = recyclerbean.get(position);

         //set data in textviews
         holder.prod_name_tv.setText(" :    "+String.valueOf(recyclerAdapterBean.getName()));
        holder.prod_price_tv.setText(" :   "+String.valueOf(recyclerAdapterBean.getPrice()));
        holder.prod_quan_tv.setText(" :    "+String.valueOf(recyclerAdapterBean.getQuant()));
        holder.prod_desc_tv.setText(" :    "+String.valueOf(recyclerAdapterBean.getDesc()));

        // click whole items to update data
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // send data to other activity.
                Intent intent = new Intent(context, UpdatItemActivity.class);
                intent.putExtra("id",    String.valueOf(recyclerAdapterBean.getId()));
                intent.putExtra("name", String.valueOf(recyclerAdapterBean.getName()));
                intent.putExtra("price",String.valueOf(recyclerAdapterBean.getPrice()));
                intent.putExtra("quan", String.valueOf(recyclerAdapterBean.getQuant()));
                intent.putExtra("desc", String.valueOf(recyclerAdapterBean.getDesc()));
                activity.startActivityForResult(intent, 1);
            }
        });


    }

    @Override
    public int getItemCount() {
        return recyclerbean.size();
    }

    class MyViewHolder extends RecyclerView.ViewHolder {

        TextView prod_name_tv, prod_price_tv, prod_quan_tv, prod_desc_tv;


        MyViewHolder(@NonNull View itemView) {
            super(itemView);

            // iniaitlize views
            prod_name_tv = itemView.findViewById(R.id.prod_name_tv);
            prod_price_tv = itemView.findViewById(R.id.prod_price_tv);
            prod_quan_tv = itemView.findViewById(R.id.prod_quan_tv);
            prod_desc_tv = itemView.findViewById(R.id.prod_desc_tv);


        }

    }
}
